#!/bin/bash

# 编译脚本
cd /home/cat/rknn-bytetrack-master
rm -rf build
mkdir -p build
cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
make -j4

# 检查编译结果
if [ -f ./yolov8_rtsp_track ]; then
    echo "编译成功！"
    
    # 复制到上级目录方便运行
    cp ./yolov8_rtsp_track ..
    
    echo "可执行文件已复制到: /home/cat/rknn-bytetrack-master/yolov8_rtsp_track"
else
    echo "编译失败！"
    exit 1
fi
