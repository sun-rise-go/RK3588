# RK3588 YOLOv8+ByteTrack 项目完成报告

## 项目概述
成功编译并配置了RK3588平台上的YOLOv8+ByteTrack目标检测与跟踪项目。

## 完成的工作

### 1. 项目分析
- 分析了项目结构和依赖关系
- 确认Eigen3已安装
- 确认OpenCV 4.2.0已安装（但不完整）

### 2. 依赖问题解决
解决了OpenCV库不完整的问题（缺少calib3d、highgui等模块）：
- 修改了所有源文件中的`#include <opencv2/opencv.hpp>`引用
- 改为按需包含独立模块：
  - `<opencv2/core.hpp>`
  - `<opencv2/imgproc.hpp>`
  - `<opencv2/imgcodecs.hpp>`
  - `<opencv2/videoio.hpp>`

### 3. 源代码修改
修改了以下文件的OpenCV头文件引用：
- `src/types/yolo_datatype.h`
- `src/process/preprocess.h`
- `src/task/yolov8.h`
- `src/draw/cv_draw.h`
- `src/bytetrack/STrack.h`
- `src/bytetrack/BYTETracker.h`
- `src/bytetrack/utils.cpp`
- `src/yolov8_video_track.cpp`
- `src/yolov8_rtsp_track.cpp`

修复了`src/bytetrack/utils.cpp`中缺少的头文件：
- 添加了`#include <map>`
- 添加了`#include <iostream>`

### 4. CMakeLists.txt优化
优化了CMake配置：
- 添加了多种OpenCV查找方式
- 添加了Eigen3的灵活查找机制
- 移除了对`Eigen3::Eigen`的显式链接

### 5. 脚本和文档创建
创建了以下辅助脚本：
- `build.sh` - 自动化构建脚本
- `run_video_track.sh` - 视频跟踪运行脚本
- `run_track.sh` - 通用跟踪运行脚本
- `test_build.sh` - 编译验证脚本

创建了以下文档：
- `USAGE.md` - 详细使用说明文档
- `COMPLETION_REPORT.md` - 本完成报告

## 编译结果

### 成功生成的可执行文件
```
build/yolov8_video_track  (108KB)  - 视频文件跟踪程序
build/yolov8_rtsp_track   (109KB)  - RTSP流跟踪程序
```

### 成功生成的库文件
```
build/librknn_engine.so    - RKNN引擎库
build/libnn_process.so     - 数据预处理/后处理库
build/libdraw_lib.so       - OpenCV绘制库
build/libbytetrack_lib.so  - ByteTrack跟踪库
build/libyolov8_lib.so     - YOLOv8任务库
```

## 使用方法

### 快速开始
```bash
cd /home/cat/rknn-bytetrack-master

# 运行视频跟踪（不录制）
./run_video_track.sh weights/yolov8s.int.rknn videos/palace.mp4 0

# 运行视频跟踪（录制）
./run_video_track.sh weights/yolov8s.int.rknn videos/palace.mp4 1
```

### 手动运行
```bash
cd /home/cat/rknn-bytetrack-master/build

# 视频文件跟踪
./yolov8_video_track ../weights/yolov8s.int.rknn ../videos/palace.mp4 0

# RTSP流跟踪
./yolov8_rtsp_track rtsp://username:password@ip:port/path
```

## 技术细节

### 模型选择
- **yolov8s.int.rknn** (14MB): INT8量化模型，推理速度快，适合实时应用
- **yolov8s.float.rknn** (26MB): FP32浮点模型，精度更高，适合离线分析

### 性能优化建议
1. 实时应用优先使用INT8量化模型
2. 根据场景调整ByteTracker参数（frame_rate, track_buffer）
3. 视频分辨率建议不超过1080p以保证流畅度

## 项目文件清单

### 可执行文件
- ✓ build/yolov8_video_track
- ✓ build/yolov8_rtsp_track

### 模型文件
- ✓ weights/yolov8s.int.rknn (14MB)
- ✓ weights/yolov8s.float.rknn (26MB)

### 测试视频
- ✓ videos/palace.mp4 (5.7MB)

### 库文件
- ✓ librknn_api/aarch64/librknnrt.so (5.1MB)
- ✓ build/librknn_engine.so
- ✓ build/libnn_process.so
- ✓ build/libdraw_lib.so
- ✓ build/libbytetrack_lib.so
- ✓ build/libyolov8_lib.so

### 脚本文件
- ✓ build.sh
- ✓ run_video_track.sh
- ✓ run_track.sh
- ✓ test_build.sh

### 文档文件
- ✓ README.md (原始)
- ✓ USAGE.md (新增)
- ✓ COMPLETION_REPORT.md (本报告)

## 系统要求

### 必需依赖
- RK3588硬件平台
- OpenCV 4.2.0 或更高版本
- Eigen3 3.3 或更高版本
- CMake 3.11 或更高版本
- GCC/G++ 9.0 或更高版本

### 已验证环境
- OS: Linux 5.10.160
- CPU: aarch64 (RK3588)
- OpenCV: 4.2.0
- Eigen3: 已安装
- CMake: 已安装
- GCC: 9.4.0

## 已知限制

1. **OpenCV模块不完整**: 系统OpenCV缺少calib3d和highgui模块，已通过修改代码解决
2. **RKNN API版本**: 模型文件需与RKNN API版本匹配
3. **内存需求**: 运行时需要足够的系统内存加载模型和视频

## 后续优化建议

1. **性能优化**
   - 使用RKNN的零拷贝特性减少数据拷贝
   - 优化视频解码流程
   - 实现多线程流水线处理

2. **功能扩展**
   - 支持多目标类别过滤
   - 添加跟踪轨迹绘制
   - 实现跟踪结果统计和导出

3. **部署优化**
   - 创建systemd服务实现开机自启
   - 添加配置文件支持参数调整
   - 实现日志记录和错误恢复

## 总结

项目已成功编译并可以正常运行。解决了OpenCV依赖问题，创建了完整的运行脚本和文档。用户现在可以：

1. 使用预编译好的可执行文件进行视频跟踪
2. 使用INT8或FP32模型进行目标检测
3. 支持视频文件和RTSP流输入
4. 可选录制跟踪结果到视频文件

项目已准备就绪，可以投入使用。
