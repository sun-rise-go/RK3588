#!/bin/bash

# RK3588 YOLOv8+ByteTrack 项目构建脚本

echo "开始构建 RK3588 YOLOv8+ByteTrack 项目..."

# 创建build目录
if [ ! -d "build" ]; then
    mkdir build
    echo "创建build目录"
fi

cd build

# 运行cmake
echo "运行cmake配置..."
cmake ..

# 编译
echo "开始编译..."
make -j4

if [ $? -eq 0 ]; then
    echo "======================================"
    echo "编译成功！"
    echo "======================================"
    echo ""
    echo "运行程序："
    echo "./yolov8_video_track <model_path> <video_path> [record]"
    echo ""
    echo "示例："
    echo "./yolov8_video_track ../weights/yolov8s.int.rknn ../videos/palace.mp4 1"
    echo ""
else
    echo "编译失败！"
    exit 1
fi
