#!/bin/bash

# 快速测试脚本 - 验证编译是否成功

echo "========================================"
echo "RK3588 YOLOv8+ByteTrack 编译验证"
echo "========================================"
echo ""

# 检查可执行文件
echo "1. 检查可执行文件..."
if [ -f "build/yolov8_video_track" ]; then
    echo "   ✓ yolov8_video_track 存在"
    ls -lh build/yolov8_video_track
else
    echo "   ✗ yolov8_video_track 不存在"
    exit 1
fi

if [ -f "build/yolov8_rtsp_track" ]; then
    echo "   ✓ yolov8_rtsp_track 存在"
    ls -lh build/yolov8_rtsp_track
else
    echo "   ✗ yolov8_rtsp_track 不存在"
    exit 1
fi

echo ""
echo "2. 检查模型文件..."
if [ -f "weights/yolov8s.int.rknn" ]; then
    echo "   ✓ yolov8s.int.rknn 存在"
    ls -lh weights/yolov8s.int.rknn
else
    echo "   ✗ yolov8s.int.rknn 不存在"
fi

if [ -f "weights/yolov8s.float.rknn" ]; then
    echo "   ✓ yolov8s.float.rknn 存在"
    ls -lh weights/yolov8s.float.rknn
else
    echo "   ✗ yolov8s.float.rknn 不存在"
fi

echo ""
echo "3. 检查测试视频..."
if [ -f "videos/palace.mp4" ]; then
    echo "   ✓ palace.mp4 存在"
    ls -lh videos/palace.mp4
else
    echo "   ✗ palace.mp4 不存在"
fi

echo ""
echo "4. 检查库文件..."
if [ -f "librknn_api/aarch64/librknnrt.so" ]; then
    echo "   ✓ librknnrt.so 存在"
    ls -lh librknn_api/aarch64/librknnrt.so
else
    echo "   ✗ librknnrt.so 不存在"
fi

echo ""
echo "========================================"
echo "编译验证完成！"
echo "========================================"
echo ""
echo "运行程序："
echo "  ./run_video_track.sh weights/yolov8s.int.rknn videos/palace.mp4 0"
echo ""
echo "更多信息请查看 USAGE.md"
