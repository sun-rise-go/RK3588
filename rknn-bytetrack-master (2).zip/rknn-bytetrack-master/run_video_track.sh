#!/bin/bash

# RK3588 YOLOv8+ByteTrack 视频文件跟踪脚本

# 检查参数
if [ $# -lt 2 ]; then
    echo "用法: ./run_video_track.sh <模型路径> <视频路径> [是否录制:0或1]"
    echo ""
    echo "示例:"
    echo "  ./run_video_track.sh weights/yolov8s.int.rknn videos/palace.mp4 0"
    echo "  ./run_video_track.sh weights/yolov8s.int.rknn videos/palace.mp4 1"
    echo ""
    echo "注意:"
    echo "  - 模型路径: weights/yolov8s.int.rknn (int8量化模型，速度快)"
    echo "  - 模型路径: weights/yolov8s.float.rknn (float32模型，精度高)"
    echo "  - 是否录制: 0=不录制(默认), 1=录制结果到result.mp4"
    exit 1
fi

MODEL_PATH=$1
VIDEO_PATH=$2
RECORD=${3:-0}

# 检查build目录是否存在
if [ ! -d "build" ]; then
    echo "错误: build目录不存在，请先运行 ./build.sh 编译项目"
    exit 1
fi

# 检查可执行文件是否存在
if [ ! -f "build/yolov8_video_track" ]; then
    echo "错误: 可执行文件不存在，请先运行 ./build.sh 编译项目"
    exit 1
fi

# 检查模型文件是否存在
if [ ! -f "$MODEL_PATH" ]; then
    echo "错误: 模型文件不存在: $MODEL_PATH"
    exit 1
fi

# 检查视频文件是否存在
if [ ! -f "$VIDEO_PATH" ]; then
    echo "错误: 视频文件不存在: $VIDEO_PATH"
    exit 1
fi

# 显示运行信息
echo "======================================"
echo "开始运行 YOLOv8+ByteTrack 视频跟踪"
echo "======================================"
echo "模型路径: $MODEL_PATH"
echo "视频路径: $VIDEO_PATH"
echo "录制: $RECORD"
echo "======================================"
echo ""

# 运行程序
cd build
./yolov8_video_track "../$MODEL_PATH" "../$VIDEO_PATH" $RECORD

echo ""
echo "运行结束"
