# RK3588 YOLOv8+ByteTrack 使用说明

## 项目简介
这是一个可以在RK3588上运行的YOLOv8+ByteTrack目标检测与跟踪项目，项目自带有量化后的官方模型可以进行测试使用。

## 编译步骤

### 1. 安装依赖
在使用ByteTrack之前需要先安装eigen3（已安装）：
```bash
# 创建任意目录并进入
mkdir eigen3_install && cd eigen3_install
# 克隆eigen3源码
git clone https://gitee.com/tangerine_yun/eigen-git-mirror.git
cd eigen-git-mirror
mkdir build && cd build
cmake ..
sudo make install
```

OpenCV库（系统已安装4.2.0版本）

### 2. 编译项目
```bash
cd /home/cat/rknn-bytetrack-master
./build.sh
```

或者手动编译：
```bash
mkdir build && cd build
cmake ..
make -j4
```

## 运行程序

### 1. 视频文件跟踪
```bash
# 不录制结果
./run_video_track.sh weights/yolov8s.int.rknn videos/palace.mp4 0

# 录制结果到result.mp4
./run_video_track.sh weights/yolov8s.int.rknn videos/palace.mp4 1
```

### 2. RTSP流跟踪
```bash
# 从RTSP流读取
./run_rtsp_track.sh rtsp://username:password@ip:port/path
```

## 参数说明

### yolov8_video_track 参数
- 参数1: 模型文件路径（.rknn文件）
- 参数2: 视频文件路径
- 参数3: 是否录制（0=不录制，1=录制，默认为0）

### 模型选择
- `weights/yolov8s.int.rknn`: int8量化模型，速度快，精度稍低
- `weights/yolov8s.float.rknn`: float32模型，精度高，速度较慢

## 输出说明

### 控制台输出
程序运行时会每秒输出一次统计信息：
- Method2 Time: 总运行时间（毫秒）
- FPS: 当前帧率
- Frame Count: 已处理帧数

### 视频输出
如果启用录制，会在build目录下生成`result.mp4`文件，包含：
- 检测框和跟踪ID
- 每帧的处理时间
- 原始视频帧率

## 性能优化

### 1. 模型选择
- 实时应用推荐使用int8量化模型
- 对精度要求高的场景使用float32模型

### 2. 跟踪参数调整
在`src/yolov8_video_track.cpp`中可以调整ByteTracker参数：
```cpp
static BYTETracker tracker(30, 30);  // (frame_rate, track_buffer)
```

## 注意事项

1. 确保模型文件和视频文件路径正确
2. 确保有足够的系统内存加载模型和视频
3. RTSP流跟踪需要稳定的网络连接
4. 模型文件必须在项目目录或提供绝对路径

## 文件结构
```
rknn-bytetrack-master/
├── build/                   # 编译输出目录
│   ├── yolov8_video_track   # 视频跟踪可执行文件
│   └── yolov8_rtsp_track    # RTSP流跟踪可执行文件
├── src/                     # 源代码
│   ├── bytetrack/           # ByteTrack算法实现
│   ├── engine/              # RKNN引擎封装
│   ├── process/             # 数据预处理和后处理
│   └── task/                # YOLOv8任务实现
├── weights/                 # 模型文件
│   ├── yolov8s.int.rknn    # int8量化模型
│   └── yolov8s.float.rknn   # float32模型
├── videos/                  # 测试视频
│   └── palace.mp4
├── CMakeLists.txt           # CMake构建配置
├── build.sh                 # 构建脚本
├── run_video_track.sh       # 视频跟踪运行脚本
└── run_rtsp_track.sh        # RTSP流跟踪运行脚本
```

## 故障排除

### 1. 编译错误 - 找不到opencv2/calib3d.hpp
系统OpenCV版本不完整，已修改源代码使用独立模块包含

### 2. 编译错误 - 找不到Eigen3
需要先安装Eigen3库

### 3. 运行时错误 - 无法打开视频文件
检查视频文件路径是否正确，文件是否存在

### 4. 运行时错误 - 无法加载模型
检查模型文件路径是否正确，文件是否损坏

## 技术支持
如遇到问题，请检查：
1. 系统是否为aarch64架构（RK3588）
2. OpenCV、Eigen3、RKNN库是否正确安装
3. 模型文件是否完整且与RKNN API版本兼容
