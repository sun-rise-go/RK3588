// 预处理

#include "preprocess.h"

#include "utils/logging.h"

// RGA加速（RK3588）
#include <rga/im2d.h>
#include <rga/rga.h>

// opencv 版本的 letterbox
LetterBoxInfo letterbox(const cv::Mat &img, cv::Mat &img_letterbox, float wh_ratio)
{

    // img has to be 3 channels
    if (img.channels() != 3)
    {
        NN_LOG_ERROR("img has to be 3 channels");
        exit(-1);
    }
    float img_width = img.cols;
    float img_height = img.rows;

    int letterbox_width = 0;
    int letterbox_height = 0;

    LetterBoxInfo info;
    int padding_hor = 0;
    int padding_ver = 0;

    if (img_width / img_height > wh_ratio)
    {
        info.hor = false;
        letterbox_width = img_width;
        letterbox_height = img_width / wh_ratio;
        info.pad = (letterbox_height - img_height) / 2.f;
        padding_hor = 0;
        padding_ver = info.pad;
    }
    else
    {
        info.hor = true;
        letterbox_width = img_height * wh_ratio;
        letterbox_height = img_height;
        info.pad = (letterbox_width - img_width) / 2.f;
        padding_hor = info.pad;
        padding_ver = 0;
    }
    /*
     * Padding an image.
                                    dst_img
        --------------      ----------------------------
        |            |      |       top_border         |
        |  src_image |  =>  |                          |
        |            |      |      --------------      |
        --------------      |left_ |            |right_|
                            |border|  dst_rect  |border|
                            |      |            |      |
                            |      --------------      |
                            |       bottom_border      |
                            ----------------------------
     */
    // 使用cv::copyMakeBorder函数进行填充边界
    cv::copyMakeBorder(img, img_letterbox, padding_ver, padding_ver, padding_hor, padding_hor, cv::BORDER_CONSTANT, cv::Scalar(0, 0, 0));
    return info;
}

// BGR->RGB + resize
// 优先走RGA（更稳定、CPU占用更低），失败则回退OpenCV
void cvimg2tensor(const cv::Mat &img, uint32_t width, uint32_t height, tensor_data_s &tensor)
{
    if (img.channels() != 3)
    {
        NN_LOG_ERROR("img has to be 3 channels");
        exit(-1);
    }

    // ---- RGA path ----
    static cv::Mat rgb_tmp;
    static cv::Mat rgb_resized;

    if (rgb_tmp.empty() || rgb_tmp.cols != img.cols || rgb_tmp.rows != img.rows || rgb_tmp.type() != CV_8UC3)
    {
        rgb_tmp = cv::Mat(img.rows, img.cols, CV_8UC3);
    }
    if (rgb_resized.empty() || rgb_resized.cols != (int)width || rgb_resized.rows != (int)height || rgb_resized.type() != CV_8UC3)
    {
        rgb_resized = cv::Mat((int)height, (int)width, CV_8UC3);
    }

    bool rga_ok = false;
    if (!img.empty() && !rgb_tmp.empty() && !rgb_resized.empty())
    {
        const int src_w = img.cols;
        const int src_h = img.rows;
        const int src_wstride = (int)(img.step / img.elemSize());

        const int mid_wstride = (int)(rgb_tmp.step / rgb_tmp.elemSize());
        const int dst_wstride = (int)(rgb_resized.step / rgb_resized.elemSize());

        rga_buffer_t src = wrapbuffer_virtualaddr((void *)img.data, src_w, src_h, RK_FORMAT_BGR_888, src_wstride, src_h);
        rga_buffer_t mid = wrapbuffer_virtualaddr((void *)rgb_tmp.data, src_w, src_h, RK_FORMAT_RGB_888, mid_wstride, src_h);
        rga_buffer_t dst = wrapbuffer_virtualaddr((void *)rgb_resized.data, (int)width, (int)height, RK_FORMAT_RGB_888, dst_wstride, (int)height);

        IM_STATUS s1 = imcvtcolor(src, mid, RK_FORMAT_BGR_888, RK_FORMAT_RGB_888);
        IM_STATUS s2 = (s1 == IM_STATUS_SUCCESS) ? imresize(mid, dst) : s1;

        if (s1 == IM_STATUS_SUCCESS && s2 == IM_STATUS_SUCCESS)
        {
            memcpy(tensor.data, rgb_resized.data, tensor.attr.size);
            rga_ok = true;
        }
    }

    if (rga_ok)
        return;

    // ---- OpenCV fallback ----
    cv::Mat img_rgb;
    cv::cvtColor(img, img_rgb, cv::COLOR_BGR2RGB);
    cv::Mat img_resized;
    cv::resize(img_rgb, img_resized, cv::Size(width, height), 0, 0, cv::INTER_LINEAR);
    memcpy(tensor.data, img_resized.data, tensor.attr.size);
}
