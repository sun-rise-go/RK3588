#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/videoio.hpp>
#ifdef HAS_DISPLAY
#include <opencv2/highgui.hpp>
#endif
#include <getopt.h>
#include <atomic>
#include <thread>
#include <mutex>
#include <queue>
#include <condition_variable>
#include <chrono>
#include <memory>
#include <csignal>
#include <sched.h>
#include <pthread.h>
#include <unistd.h>
#include <cstring>
#include <cmath>
#include <vector>
#include <algorithm>
#include <deque>

#include "task/yolov8.h"
#include "utils/logging.h"
#include "draw/cv_draw.h"

#include "bytetrack/BYTETracker.h"

// ========== 配置参数 ==========
// 目标：不积压、丢旧保新、推流不反压主循环；并且“输出帧率固定”来消除播放端抖动。
#define MAX_QUEUE_SIZE 1
#define PUSH_QUEUE_SIZE 3
#define PRINT_FPS_INTERVAL 8000
#define DEFAULT_FPS 25
#define TARGET_PUSH_FPS 20

// ========== 信号处理 ==========
static std::atomic<bool> g_signal_received{false};

void signal_handler(int signum) {
    g_signal_received = true;
}

static inline void bind_thread_to_cpu(int cpu_id) {
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cpu_id, &set);
    pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &set);
}

static inline std::string shell_escape_single_quotes(const std::string& s) {
    // For popen("...", ...) which runs via /bin/sh -c
    // wrap with single quotes and escape any embedded single quote.
    std::string out;
    out.reserve(s.size() + 8);
    for (char c : s) {
        if (c == '\'') {
            out += "'\\''";
        } else {
            out.push_back(c);
        }
    }
    return out;
}

// ========== 带时间戳的帧结构体（零拷贝优化）==========
struct TimedFrame {
    std::shared_ptr<cv::Mat> mat_ptr;
    std::chrono::steady_clock::time_point timestamp;

    cv::Mat& mat_ref() { return *mat_ptr; }
    const cv::Mat& mat_ref() const { return *mat_ptr; }
};

// ========== 线程安全帧队列（零拷贝优化）==========
class ThreadSafeQueue {
private:
    std::deque<TimedFrame> queue_;
    mutable std::mutex mutex_;
    std::condition_variable cond_;
    size_t max_size_;
    std::atomic<bool> stop_{false};

public:
    explicit ThreadSafeQueue(size_t max_size = MAX_QUEUE_SIZE) : max_size_(max_size) {}

    ~ThreadSafeQueue() { stop(); }

    void stop() {
        stop_ = true;
        cond_.notify_all();
    }

    bool push(TimedFrame&& frame) {
        std::unique_lock<std::mutex> lock(mutex_);

        // 队列满时丢弃最老帧,保留最新帧
        if (queue_.size() >= max_size_) {
            queue_.pop_front();
        }

        queue_.push_back(std::move(frame));
        lock.unlock();
        cond_.notify_one();
        return true;
    }

    bool pop(TimedFrame& frame) {
        std::unique_lock<std::mutex> lock(mutex_);

        if (cond_.wait_for(lock, std::chrono::milliseconds(5),
                          [this]() { return !queue_.empty() || stop_; })) {
            if (stop_ && queue_.empty()) {
                return false;
            }

            if (!queue_.empty()) {
                frame = std::move(queue_.front());
                queue_.pop_front();
                return true;
            }
        }
        return false;
    }

    // 非阻塞弹出（用于快速“取最新帧”，避免积压导致延迟飙升）
    bool try_pop(TimedFrame& frame) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (queue_.empty()) return false;
        frame = std::move(queue_.front());
        queue_.pop_front();
        return true;
    }

    size_t size() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return queue_.size();
    }

    bool empty() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return queue_.empty();
    }
};

void decobj_to_trackobj(std::vector<Detection> &objects, std::vector<Object> &trackobj)
{
    trackobj.clear();
    for (auto &obj : objects)
    {
        // 只检测和跟踪 person (class_id = 0)
        if (obj.class_id != 0) continue;

        Object trackobj_temp;
        trackobj_temp.classId = obj.class_id;
        trackobj_temp.score = obj.confidence;
        trackobj_temp.box = obj.box;
        trackobj.push_back(trackobj_temp);
    }
}

int main(int argc, char **argv)
{
    // 注册信号处理
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    // 环境变量优化：低延迟优先。
    // 你现在看到的“cap.read 阻塞 + 大量h264解码错误”，本质是上游RTSP链路/码流质量问题。
    // 这里提供可切换策略：
    //   - RTSP_TRANSPORT=udp  : 宁可丢包也不等（延迟更稳，但码流差会出现解码错误/花屏）
    //   - RTSP_TRANSPORT=tcp  : 不丢包但可能等重传（更完整，但可能出现长阻塞）
    // 默认用TCP更稳（你这路码流在UDP下大量解码错误）；如要最低延迟再显式 RTSP_TRANSPORT=udp
    const char* tr_env = getenv("RTSP_TRANSPORT");
    const bool use_udp = (tr_env && (strcmp(tr_env, "udp") == 0 || strcmp(tr_env, "UDP") == 0));
    const char* tr_opt = use_udp ? "udp" : "tcp";

    // 对齐你 Go 的“稳定读取”策略：更温和的 max_delay + 更长的超时（避免2秒一抖）
    std::string cap_opts = std::string("rtsp_transport;") + tr_opt +
                           "|fflags;nobuffer|flags;low_delay|err_detect;ignore_err";
    cap_opts += "|max_delay;100000|timeout;10000000|rw_timeout;10000000|buffer_size;102400";

    // 允许脚本/外部覆盖（USE_RELAY=1 时脚本会把 query 参数挂在URL上；这里也支持直接设置 env）
    const char* ext_opts = getenv("OPENCV_FFMPEG_CAPTURE_OPTIONS");
    if (ext_opts && *ext_opts) {
        printf("使用外部 OPENCV_FFMPEG_CAPTURE_OPTIONS=%s\n", ext_opts);
    } else {
        setenv("OPENCV_FFMPEG_CAPTURE_OPTIONS", cap_opts.c_str(), 1);
        printf("OPENCV_FFMPEG_CAPTURE_OPTIONS=%s\n", cap_opts.c_str());
    }

    setenv("LD_LIBRARY_PATH", "/usr/lib:/usr/lib/aarch64-linux-gnu:/usr/lib/rk3588", 1);
    setenv("RKNN_TARGET_PLATFORM", "rk3588", 1);
    setenv("RKNN_MODEL_DIR", "/usr/lib/rknn-model", 1);
    setenv("RKNN_LOG_LEVEL", "ERROR", 1);

    // 打印启动信息
    printf("========================================\n");
    printf("YOLOv8 + ByteTrack RK3588 (优化版)\n");
    printf("========================================\n");

    if (argc < 3)
    {
        printf("Usage: %s <model_file> <input_rtsp_url> [output_rtsp_url] [record] [detect_interval]\n", argv[0]);
        printf("Example: %s weights/yolov8s.int.rknn rtsp://192.168.1.100:554/stream rtsp://127.0.0.1:37000/stream 0 2\n", argv[0]);
        return -1;
    }

    const char *model_file = argv[1];
    const char *input_rtsp = argv[2];
    const char *output_rtsp = argc > 3 ? argv[3] : nullptr;
    const bool record = argc > 4 ? (atoi(argv[4]) != 0) : false;
    const int detect_interval = argc > 5 ? std::max(1, atoi(argv[5])) : 3;  // 检测间隔：每N帧检测一次，默认3

    printf("模型: %s\n", model_file);
    printf("输入: %s\n", input_rtsp);
    printf("输出: %s\n", output_rtsp ? output_rtsp : "无");
    printf("检测间隔: 每%d帧检测一次\n", detect_interval);
    printf("类别过滤: 只检测 person (class_id=0)\n");
    printf("========================================\n");

    // 设置CPU亲和性（与main1_reid.cpp一致，绑定0-3大核）
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    for (int i = 0; i < 4; i++) {
        CPU_SET(i, &cpuset);
    }
    sched_setaffinity(0, sizeof(cpu_set_t), &cpuset);
    printf("CPU亲和性: 绑定到核心0-3 (A76 2.4GHz)\n");

    // ========= 初始化视频源（绕开 VideoCapture：默认用 ffmpeg rawvideo pipe 读帧） =========
    const char* cap_env = getenv("USE_OPENCV_CAP");
    const bool use_opencv_cap = (cap_env && *cap_env && atoi(cap_env) != 0);
    printf("正在打开视频源: %s\n", input_rtsp);
    printf("输入读取模式: %s\n", use_opencv_cap ? "opencv-cap" : "ffmpeg-pipe");

    int width = 1920;
    int height = 1080;
    int fps = DEFAULT_FPS;
    if (const char* wenv = getenv("INPUT_W")) { if (*wenv) width = atoi(wenv); }
    if (const char* henv = getenv("INPUT_H")) { if (*henv) height = atoi(henv); }
    if (const char* fenv = getenv("INPUT_FPS")) { if (*fenv) fps = atoi(fenv); }
    if (fps <= 0) fps = DEFAULT_FPS;

    cv::VideoCapture cap;
    if (use_opencv_cap) {
        // 强制用FFmpeg后端，避免不同backend行为差异导致卡顿/缓冲不可控
        cap.open(input_rtsp, cv::CAP_FFMPEG);
        if (!cap.isOpened())
        {
            NN_LOG_ERROR("Failed to open RTSP stream: %s", input_rtsp);
            return -1;
        }

        cap.set(cv::CAP_PROP_BUFFERSIZE, 1);
        cap.set(cv::CAP_PROP_FPS, DEFAULT_FPS);
        cap.set(cv::CAP_PROP_FRAME_WIDTH, width);
        cap.set(cv::CAP_PROP_FRAME_HEIGHT, height);
        cap.set(cv::CAP_PROP_FPS, DEFAULT_FPS);
        cap.set(cv::CAP_PROP_BUFFERSIZE, 1);

        width = cap.get(cv::CAP_PROP_FRAME_WIDTH);
        height = cap.get(cv::CAP_PROP_FRAME_HEIGHT);
        fps = cap.get(cv::CAP_PROP_FPS);
        if (fps <= 0) fps = DEFAULT_FPS;
    }

    printf("视频: %dx%d @ %d fps\n", width, height, fps);

    // ========= 初始化YOLO模型 =========
    printf("正在加载模型...\n");
    Yolov8Custom yolo;
    yolo.LoadModel(model_file);
    printf("模型加载完成\n");

    // ========= 初始化FFmpeg推流 =========
    FILE *ffmpeg_pipe = nullptr;
    std::string ffmpeg_cmd;

    if (output_rtsp)
    {
        const int out_fps = TARGET_PUSH_FPS;
        const int gop = std::max(10, out_fps);

        // 推流侧传输方式单独可控：默认TCP更稳（避免UDP丢包导致“肉眼一卡一卡”）
        // 需要UDP再显式：PUSH_RTSP_TRANSPORT=udp
        const char* ptr_env = getenv("PUSH_RTSP_TRANSPORT");
        const bool push_udp = (ptr_env && (strcmp(ptr_env, "udp") == 0 || strcmp(ptr_env, "UDP") == 0));
        const char* push_tr = push_udp ? "udp" : "tcp";

        // 推流：固定输出帧率（即使输入/推理抖动，也尽量让播放端“匀速”）；低延迟参数。
        ffmpeg_cmd = "ffmpeg -y -loglevel error "
                     "-fflags nobuffer -flags low_delay "
                     "-f rawvideo -vcodec rawvideo -pix_fmt bgr24 "
                     "-s " + std::to_string(width) + "x" + std::to_string(height) +
                     " -r " + std::to_string(out_fps) + " -i - "
                     "-an -c:v h264_rkmpp -b:v 3M -maxrate 3M -bufsize 600k -pix_fmt yuv420p "
                     "-g " + std::to_string(gop) + " -bf 0 -profile:v main "
                     "-muxdelay 0 -muxpreload 0 -flush_packets 1 "
                     "-f rtsp -rtsp_transport " + std::string(push_tr) + " "
                     "-timeout 5000000 "
                     + std::string(output_rtsp);

        ffmpeg_pipe = popen(ffmpeg_cmd.c_str(), "w");
        if (!ffmpeg_pipe)
        {
            NN_LOG_ERROR("Failed to open FFmpeg pipe");
            return -1;
        }
        setbuf(ffmpeg_pipe, NULL);
        printf("FFmpeg推流已启动: %s (%s传输，5秒超时)\n", output_rtsp, push_udp ? "UDP" : "TCP");
    }

    // ========= 初始化录像 =========
    cv::VideoWriter writer;
    if (record)
    {
        writer = cv::VideoWriter("result_rtsp.mp4", cv::VideoWriter::fourcc('m', 'p', '4', 'v'), fps, cv::Size(width, height));
    }

    // ========= 初始化BYTETracker ==========
    std::vector<Object> trackobj;
    std::vector<STrack> output_stracks;
    std::vector<STrack> last_tracked_stracks;  // 保存上一次的跟踪结果，用于预测
    BYTETracker tracker(fps, fps * 10);
    printf("BYTETracker已初始化 (track_buffer=%d帧)\n", fps * 10);

    // ========= 队列初始化：输入单缓冲 + 推流小缓冲（推流独立线程，避免fwrite阻塞造成“卡一下”） =========
    ThreadSafeQueue frame_queue(MAX_QUEUE_SIZE);
    ThreadSafeQueue push_queue(PUSH_QUEUE_SIZE);

    std::atomic<bool> running{true};
    std::atomic<int64_t> frame_counter{0};
    std::atomic<int64_t> processed_counter{0};
    std::atomic<int64_t> skipped_counter{0};  // 丢弃的旧帧数（为低延迟服务）

    std::atomic<bool> push_enabled{true};
    std::atomic<int> push_fail_count{0};

    // ========= FPS统计变量（与main1_reid.cpp一致） =========
    auto last_fps_time = std::chrono::steady_clock::now();
    int fps_count = 0;
    auto last_frame_time = std::chrono::steady_clock::now();
    double fps_ema = 0.0;
    const double fps_alpha = 0.90;

    // 分段耗时统计
    double det_ms_ema = 0.0, trk_ms_ema = 0.0, drw_ms_ema = 0.0;
    double det_ms_max = 0.0, trk_ms_max = 0.0, drw_ms_max = 0.0;
    std::atomic<double> psh_ms_ema{0.0};
    std::atomic<double> psh_ms_max{0.0};
    const double ms_alpha = 0.90;

    // cap.read 阻塞统计（避免刷屏：只在状态行里汇总 + 少量节流打印）
    std::atomic<int64_t> cap_block_cnt{0};
    std::atomic<double> cap_block_max{0.0};

    // 读取线程：默认使用 ffmpeg rawvideo pipe（彻底绕开 VideoCapture 的不可控阻塞）
    std::thread capture_thread([&]() {
        printf("读取线程已启动 (%s)\n", use_opencv_cap ? "opencv-cap" : "ffmpeg-pipe");
        int read_fail_count = 0;
        std::string rtsp_url = input_rtsp;

        auto last_block_log = std::chrono::steady_clock::now() - std::chrono::seconds(10);

        FILE* in_pipe = nullptr;
        std::string in_cmd;

        auto open_pipe = [&]() -> bool {
            if (in_pipe) {
                pclose(in_pipe);
                in_pipe = nullptr;
            }
            const std::string esc_url = shell_escape_single_quotes(rtsp_url);
            const int out_fps = std::max(1, fps);

            // 直接让 ffmpeg 解码并输出 rawvideo(bgr24)，保证一帧就是固定字节数，读起来不会“等待关键帧/重排”卡住主逻辑
            // 注意：url 里可能带 &，必须做 shell 转义，否则会被 /bin/sh 当成后台符号。
            in_cmd = std::string("ffmpeg -loglevel error ") +
                     "-rtsp_transport tcp -fflags +discardcorrupt+igndts+genpts -err_detect ignore_err "
                     "-timeout 10000000 -rw_timeout 10000000 "
                     "-i '" + esc_url + "' "
                     "-an -vf fps=" + std::to_string(out_fps) + " "
                     "-pix_fmt bgr24 -f rawvideo -";

            in_pipe = popen(in_cmd.c_str(), "r");
            if (!in_pipe) {
                printf("打开ffmpeg输入管道失败\n");
                return false;
            }
            setbuf(in_pipe, NULL);
            return true;
        };

        if (!use_opencv_cap) {
            if (!open_pipe()) {
                running = false;
                return;
            }
        }

        const size_t expected = static_cast<size_t>(width) * static_cast<size_t>(height) * 3;

        while (running) {
            if (g_signal_received) {
                printf("收到信号，正在停止...\n");
                running = false;
                break;
            }

            auto read_t0 = std::chrono::steady_clock::now();

            std::shared_ptr<cv::Mat> mat_ptr;
            bool ok = false;

            if (use_opencv_cap) {
                cv::Mat frame;
                ok = cap.read(frame);
                if (ok && !frame.empty()) {
                    mat_ptr = std::make_shared<cv::Mat>(std::move(frame));
                }
            } else {
                mat_ptr = std::make_shared<cv::Mat>(height, width, CV_8UC3);
                size_t got = 0;
                while (got < expected && running) {
                    const size_t n = fread(mat_ptr->data + got, 1, expected - got, in_pipe);
                    if (n == 0) break;
                    got += n;
                }
                ok = (got == expected);
            }

            auto read_t1 = std::chrono::steady_clock::now();
            const double read_ms = std::chrono::duration_cast<std::chrono::duration<double, std::milli>>(read_t1 - read_t0).count();
            if (read_ms > 200.0) {
                cap_block_cnt.fetch_add(1, std::memory_order_relaxed);
                double prev_max = cap_block_max.load(std::memory_order_relaxed);
                while (read_ms > prev_max && !cap_block_max.compare_exchange_weak(prev_max, read_ms, std::memory_order_relaxed)) {
                }

                const auto now = std::chrono::steady_clock::now();
                if (now - last_block_log > std::chrono::seconds(2)) {
                    printf("in.read 阻塞 %.0f ms\n", read_ms);
                    last_block_log = now;
                }
            }

            if (!ok || !mat_ptr || mat_ptr->empty()) {
                read_fail_count++;
                if (read_fail_count % 10 == 1) {
                    printf("读取帧失败 (次数: %d)...\n", read_fail_count);
                }

                if (!use_opencv_cap && read_fail_count >= 10) {
                    printf("输入管道异常，重启ffmpeg输入...\n");
                    std::this_thread::sleep_for(std::chrono::milliseconds(200));
                    open_pipe();
                    read_fail_count = 0;
                }

                std::this_thread::sleep_for(std::chrono::milliseconds(5));
                continue;
            }

            read_fail_count = 0;
            frame_counter++;

            TimedFrame timed_frame;
            timed_frame.mat_ptr = std::move(mat_ptr);
            timed_frame.timestamp = std::chrono::steady_clock::now();

            frame_queue.push(std::move(timed_frame));
        }

        if (in_pipe) {
            pclose(in_pipe);
            in_pipe = nullptr;
        }
        printf("读取线程已停止\n");
    });

    // 推流线程：固定节拍输出（TARGET_PUSH_FPS），即使输入/推理抖动也尽量让播放端“匀速”。
    // 逻辑：每个tick取push_queue里最新一帧；如果没新帧就重复发送上一帧（用来抹平卡顿体感）。
    std::thread push_thread;
    if (ffmpeg_pipe && output_rtsp) {
        push_thread = std::thread([&]() {
            printf("推流线程已启动 (target=%d fps)\n", TARGET_PUSH_FPS);
            int flush_counter = 0;
            auto disabled_until = std::chrono::steady_clock::time_point::min();

            std::shared_ptr<cv::Mat> last_sent;

            const auto frame_period = std::chrono::microseconds(1000000 / std::max(1, TARGET_PUSH_FPS));
            auto next_tick = std::chrono::steady_clock::now();

            while (running || !push_queue.empty()) {
                if (g_signal_received) {
                    running = false;
                }

                const auto now = std::chrono::steady_clock::now();
                if (now < next_tick) {
                    std::this_thread::sleep_for(std::chrono::milliseconds(1));
                    continue;
                }
                // 如果线程被阻塞太久，不要“追赶补帧”导致发送突发（播放端会更抖）
                if (now - next_tick > frame_period * 3) {
                    next_tick = now;
                }
                next_tick += frame_period;

                if (!push_enabled.load(std::memory_order_relaxed)) {
                    if (disabled_until != std::chrono::steady_clock::time_point::min() && now >= disabled_until) {
                        push_enabled.store(true, std::memory_order_relaxed);
                        push_fail_count.store(0, std::memory_order_relaxed);
                        disabled_until = std::chrono::steady_clock::time_point::min();
                        printf("重新启用推流...\n");
                    } else {
                        TimedFrame drop;
                        while (push_queue.try_pop(drop)) {
                        }
                        continue;
                    }
                }

                // 取最新帧
                TimedFrame out;
                bool got = false;
                while (push_queue.try_pop(out)) {
                    got = true;
                }
                if (got) {
                    last_sent = out.mat_ptr;
                }

                if (!last_sent || last_sent->empty() || !ffmpeg_pipe) {
                    continue;
                }

                const cv::Mat& m = *last_sent;
                auto push_start = std::chrono::steady_clock::now();

                size_t written = 0;
                if (m.isContinuous()) {
                    const size_t expected = m.total() * m.elemSize();
                    written = fwrite(m.data, 1, expected, ffmpeg_pipe);
                    if (written != expected) {
                        const int fc = push_fail_count.fetch_add(1) + 1;
                        if (fc % 5 == 1) {
                            printf("推流错误: written=%zu, expected=%zu (失败计数:%d)\n", written, expected, fc);
                        }
                        fflush(ffmpeg_pipe);
                        if (fc > 10) {
                            push_enabled.store(false, std::memory_order_relaxed);
                            disabled_until = std::chrono::steady_clock::now() + std::chrono::seconds(5);
                            printf("推流连续失败，暂时禁用推流5秒...\n");
                        }
                    } else {
                        push_fail_count.store(0, std::memory_order_relaxed);
                        if (++flush_counter % 10 == 0) {
                            fflush(ffmpeg_pipe);
                        }
                    }
                } else {
                    const size_t row_bytes = static_cast<size_t>(m.cols) * m.elemSize();
                    const size_t expected = row_bytes * static_cast<size_t>(m.rows);
                    for (int r = 0; r < m.rows; ++r) {
                        written += fwrite(m.ptr(r), 1, row_bytes, ffmpeg_pipe);
                    }
                    if (written != expected) {
                        const int fc = push_fail_count.fetch_add(1) + 1;
                        if (fc % 5 == 1) {
                            printf("推流错误: written=%zu, expected=%zu (失败计数:%d)\n", written, expected, fc);
                        }
                        fflush(ffmpeg_pipe);
                        if (fc > 10) {
                            push_enabled.store(false, std::memory_order_relaxed);
                            disabled_until = std::chrono::steady_clock::now() + std::chrono::seconds(5);
                            printf("推流连续失败，暂时禁用推流5秒...\n");
                        }
                    } else {
                        push_fail_count.store(0, std::memory_order_relaxed);
                        if (++flush_counter % 10 == 0) {
                            fflush(ffmpeg_pipe);
                        }
                    }
                }

                auto push_end = std::chrono::steady_clock::now();
                const double p_ms = std::chrono::duration_cast<std::chrono::duration<double, std::milli>>(push_end - push_start).count();
                const double prev = psh_ms_ema.load(std::memory_order_relaxed);
                const double next = (prev <= 0.0) ? p_ms : (ms_alpha * prev + (1.0 - ms_alpha) * p_ms);
                psh_ms_ema.store(next, std::memory_order_relaxed);

                double prev_max = psh_ms_max.load(std::memory_order_relaxed);
                while (p_ms > prev_max && !psh_ms_max.compare_exchange_weak(prev_max, p_ms, std::memory_order_relaxed)) {
                }
            }

            printf("推流线程已停止\n");
        });
    }

    // 等待第一帧初始化
    printf("等待第一帧...\n");
    TimedFrame first_frame;
    while (running && frame_queue.empty()) {
        if (g_signal_received) break;
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    if (!frame_queue.pop(first_frame)) {
        printf("等待第一帧超时！\n");
        running = false;
    } else {
        printf("收到第一帧: %dx%d\n", first_frame.mat_ref().cols, first_frame.mat_ref().rows);
    }

    printf("开始处理循环...\n");

    while (running || !frame_queue.empty())
    {
        if (g_signal_received) {
            printf("收到信号，正在停止...\n");
            running = false;
            break;
        }

        TimedFrame timed_frame;
        if (!frame_queue.pop(timed_frame)) {
            if (!running) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            continue;
        }

        // 取“最新帧”模式：如果pop后又有新帧到来，快速丢弃旧帧，保证低延迟/不积压
        TimedFrame newer;
        while (frame_queue.try_pop(newer)) {
            timed_frame = std::move(newer);
            const int64_t sc = skipped_counter.fetch_add(1) + 1;
            if (sc % 200 == 1) {
                printf("丢弃旧帧(取最新) 已丢:%ld\n", sc);
            }
        }

        auto process_start = std::chrono::steady_clock::now();
        {
            const double dt_ms = std::chrono::duration_cast<std::chrono::duration<double, std::milli>>(process_start - last_frame_time).count();
            if (dt_ms > 0.0) {
                const double inst_fps = 1000.0 / dt_ms;
                fps_ema = (fps_ema <= 0.0) ? inst_fps : (fps_alpha * fps_ema + (1.0 - fps_alpha) * inst_fps);
            }
            last_frame_time = process_start;
        }

        // 检测/跟踪（关键：detect_interval>1 时，只在部分帧跑检测，其余帧用Kalman预测）
        double det_ms = 0.0;
        double trk_ms = 0.0;

        const bool do_detect = (detect_interval <= 1) || ((processed_counter.load() % detect_interval) == 0);

        if (do_detect) {
            // 检测帧：运行YOLO + ByteTrack更新
            auto det_start = process_start;
            std::vector<Detection> detections;
            yolo.Run(timed_frame.mat_ref(), detections);
            auto det_end = std::chrono::steady_clock::now();
            det_ms = std::chrono::duration_cast<std::chrono::duration<double, std::milli>>(det_end - det_start).count();

            auto trk_start = std::chrono::steady_clock::now();
            trackobj.clear();
            decobj_to_trackobj(detections, trackobj);
            output_stracks = tracker.update(trackobj);
            auto trk_end = std::chrono::steady_clock::now();
            trk_ms = std::chrono::duration_cast<std::chrono::duration<double, std::milli>>(trk_end - trk_start).count();
        } else {
            // 非检测帧：只做Kalman预测（使用predict_only）
            auto trk_start = process_start;
            output_stracks = tracker.predict_only();
            auto trk_end = std::chrono::steady_clock::now();
            trk_ms = std::chrono::duration_cast<std::chrono::duration<double, std::milli>>(trk_end - trk_start).count();
        }

        // 绘制（简化版本，只绘制必要元素）
        auto draw_start = std::chrono::steady_clock::now();
        for (size_t i = 0; i < output_stracks.size(); i++)
        {
            std::vector<float> tlwh = output_stracks[i].tlwh;
            if (tlwh[2] <= 0 || tlwh[3] <= 0) continue;

            int x = static_cast<int>(tlwh[0]);
            int y = static_cast<int>(tlwh[1]);
            int w = static_cast<int>(tlwh[2]);
            int h = static_cast<int>(tlwh[3]);

            // 裁剪到图像边界
            x = std::max(0, x);
            y = std::max(0, y);
            w = std::min(w, timed_frame.mat_ref().cols - x);
            h = std::min(h, timed_frame.mat_ref().rows - y);

            if (w <= 0 || h <= 0) continue;

            // 简化绘制：只绘制框和ID，减少字体大小和线宽
            cv::Scalar s = tracker.get_color(output_stracks[i].track_id);
            cv::putText(timed_frame.mat_ref(), cv::format("%d", output_stracks[i].track_id),
                       cv::Point(x + 2, y + 18),
                       cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(255, 255, 255), 1);
            cv::rectangle(timed_frame.mat_ref(), cv::Rect(x, y, w, h), s, 2);
        }
        auto draw_end = std::chrono::steady_clock::now();
        double drw_ms = std::chrono::duration_cast<std::chrono::duration<double, std::milli>>(draw_end - draw_start).count();

        // 分段耗时统计
        {
            det_ms_ema = (det_ms_ema <= 0.0) ? det_ms : (ms_alpha * det_ms_ema + (1.0 - ms_alpha) * det_ms);
            trk_ms_ema = (trk_ms_ema <= 0.0) ? trk_ms : (ms_alpha * trk_ms_ema + (1.0 - ms_alpha) * trk_ms);
            drw_ms_ema = (drw_ms_ema <= 0.0) ? drw_ms : (ms_alpha * drw_ms_ema + (1.0 - ms_alpha) * drw_ms);

            det_ms_max = std::max(det_ms_max, det_ms);
            trk_ms_max = std::max(trk_ms_max, trk_ms);
            drw_ms_max = std::max(drw_ms_max, drw_ms);
        }

        // 绘制FPS和对象数（简化版本，减少计算）
        char fps_text[64];
        snprintf(fps_text, sizeof(fps_text), "FPS:%.1f O:%zu", fps_ema, output_stracks.size());
        cv::putText(timed_frame.mat_ref(), fps_text, cv::Point(10, 25),
                   cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(255, 255, 255), 1);

        // 推流：主循环只“投递”到推流队列，实际写入在推流线程，避免写阻塞导致卡顿
        if (ffmpeg_pipe && output_rtsp) {
            TimedFrame out;
            out.mat_ptr = timed_frame.mat_ptr;
            out.timestamp = timed_frame.timestamp;
            push_queue.push(std::move(out));
        }

        // 录像
        if (record)
        {
            writer << timed_frame.mat_ref();
        }

        // 实时显示
#ifdef HAS_DISPLAY
        if (getenv("DISPLAY") != nullptr) {
            cv::Mat display_frame;
            cv::resize(timed_frame.mat_ref(), display_frame, cv::Size(960, 540));
            cv::imshow("YOLOv8 Tracking", display_frame);

            if (cv::waitKey(1) == 27) {
                printf("ESC pressed, stopping...\n");
                running = false;
                break;
            }
        }
#endif

        processed_counter++;
        fps_count++;

        // FPS统计
        auto now_time = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now_time - last_fps_time).count();

        // 每8秒打印一次
        if (elapsed >= PRINT_FPS_INTERVAL)
        {
            float current_fps = fps_count * 1000.0f / elapsed;
            const double push_ema = psh_ms_ema.load(std::memory_order_relaxed);
            const double push_max = psh_ms_max.load(std::memory_order_relaxed);
            const double age_ms = std::chrono::duration_cast<std::chrono::duration<double, std::milli>>(now_time - timed_frame.timestamp).count();
            const int64_t blk_cnt = cap_block_cnt.exchange(0, std::memory_order_relaxed);
            const double blk_max = cap_block_max.exchange(0.0, std::memory_order_relaxed);

            printf("Status | FPS: %.1f | Frame: %ld | Tracks: %zu | age(ms): %.0f | det(ms): %.1f (max %.1f) | trk(ms): %.1f (max %.1f) | drw(ms): %.1f (max %.1f) | psh(ms): %.1f (max %.1f) | capblk:%ld max:%.0f | q(in/push): %zu/%zu\n",
                   std::round(current_fps * 10.0f) / 10.0f,
                   processed_counter.load(),
                   output_stracks.size(),
                   std::round(age_ms),
                   std::round(det_ms_ema * 10.0) / 10.0, std::round(det_ms_max * 10.0) / 10.0,
                   std::round(trk_ms_ema * 10.0) / 10.0, std::round(trk_ms_max * 10.0) / 10.0,
                   std::round(drw_ms_ema * 10.0) / 10.0, std::round(drw_ms_max * 10.0) / 10.0,
                   std::round(push_ema * 10.0) / 10.0, std::round(push_max * 10.0) / 10.0,
                   blk_cnt, std::round(blk_max),
                   frame_queue.size(),
                   push_queue.size());

            fps_count = 0;
            last_fps_time = now_time;
            det_ms_max = trk_ms_max = drw_ms_max = 0.0;
            psh_ms_max.store(0.0, std::memory_order_relaxed);
        }
    }

    // 等待线程结束
    running = false;
    frame_queue.stop();
    push_queue.stop();
    if (capture_thread.joinable()) capture_thread.join();
    if (push_thread.joinable()) push_thread.join();

    // 清理资源
    printf("正在清理资源...\n");
    if (ffmpeg_pipe)
    {
        pclose(ffmpeg_pipe);
        printf("FFmpeg管道已关闭\n");
    }

    if (record && writer.isOpened())
    {
        writer.release();
    }

    cap.release();

#ifdef HAS_DISPLAY
    if (getenv("DISPLAY") != nullptr) {
        cv::destroyAllWindows();
    }
#endif

    printf("程序退出成功\n");
    return 0;
}
