#!/bin/bash

# 运行RTSP推流跟踪程序
# 参数: <model_path> <input_rtsp> [output_rtsp] [record] [detect_interval]

MODEL_PATH="${1:-./weights/yolov8s.int.rknn}"
INPUT_RTSP="${2:-rtsp://admin:abcd1234@192.168.1.19:554/streaming/channels/101}"
OUTPUT_RTSP="${3:-rtsp://192.168.1.83:8554/live}"
RECORD="${4:-0}"
DETECT_INTERVAL="${5:-5}"  # 默认5，每5帧检测一次（优先保证流畅度）

echo "========================================"
echo "YOLOv8 + ByteTrack RK3588 (优化版)"
echo "========================================"
echo "模型路径: $MODEL_PATH"
echo "输入RTSP: $INPUT_RTSP"
echo "输出RTSP: $OUTPUT_RTSP"
echo "是否录像: $RECORD"
echo "检测间隔: 每$DETECT_INTERVAL帧检测一次"
echo "========================================"
echo "优化内容："
echo "  - 间隔检测 (每N帧检测一次，其余帧仅Kalman预测)"
echo "  - RK3588硬件编码 (h264_rkmpp)"
echo "  - GOP优化 (0.5s关键帧间隔)"
echo "  - 禁用B帧 (减少编码延迟)"
echo "  - 零缓冲推流 (setbuf禁用)"
echo "  - RTSP低延迟配置 (discardcorrupt, nobuffer)"
echo "  - 单线程同步处理 (无锁竞争)"
echo "  - EMA平滑FPS显示"
echo "  - 自动跳帧 (队列积压时丢弃旧帧)"
echo "  - Person-only检测 (只检测人体)"
echo "========================================"
echo "检测间隔说明："
echo "  1: 每帧检测 (高精度，低FPS ~5-8)"
echo "  2: 每2帧检测 (FPS ~8-10)"
echo "  3: 每3帧检测 (FPS ~10-12)"
echo "  4: 每4帧检测 (FPS ~12-15)"
echo "  5: 每5帧检测 (推荐，FPS ~15-18)"
echo "  6: 每6帧检测 (最高FPS ~18-22，精度下降)"
echo "========================================"

cd /home/cat/rknn-bytetrack-master

# 设置环境变量
export LD_LIBRARY_PATH="/usr/lib:/usr/lib/aarch64-linux-gnu:/usr/lib/rk3588"
export RKNN_LOG_LEVEL="ERROR"

# ========== 颠覆性方案：RTSP整形代理（把网络抖动/时间戳异常隔离在推理进程之外） ==========
# 用法：
#   USE_RELAY=1 RELAY_INPUT_RTSP=rtsp://xxx/main ./run_rtsp_track.sh
# 可选：
#   MEDIA_MTX_BIN=/home/cat/lwj/media/mediamtx
#   MEDIA_MTX_CONF=/home/cat/lwj/media/mediamtx.yml
#   RELAY_STREAM_NAME=fixed_stream
#
# 说明：
#   - relay 会把摄像头RTSP拉流 -> 重新编码(h264_rkmpp) -> 推到本机 mediamtx 的 fixed_stream
#   - 主程序只读取本机 fixed_stream（相当于“本地视频般稳定”）

RELAY_PID=""
MEDIAMTX_PID=""
cleanup() {
  if [ -n "$RELAY_PID" ]; then
    kill "$RELAY_PID" >/dev/null 2>&1 || true
  fi
  if [ -n "$MEDIAMTX_PID" ]; then
    kill "$MEDIAMTX_PID" >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT INT TERM

if [ "${USE_RELAY:-0}" = "1" ]; then
  MEDIA_MTX_BIN="${MEDIA_MTX_BIN:-/home/cat/lwj/media/mediamtx}"
  MEDIA_MTX_CONF="${MEDIA_MTX_CONF:-/home/cat/lwj/media/mediamtx.yml}"
  RELAY_STREAM_NAME="${RELAY_STREAM_NAME:-fixed_stream}"
  RELAY_INPUT_RTSP="${RELAY_INPUT_RTSP:-$INPUT_RTSP}"

  if [ ! -x "$MEDIA_MTX_BIN" ]; then
    echo "USE_RELAY=1 但找不到 mediamtx 可执行文件: $MEDIA_MTX_BIN"
    echo "请设置 MEDIA_MTX_BIN=/path/to/mediamtx"
    exit 2
  fi

  RELAY_URL="rtsp://127.0.0.1:8554/${RELAY_STREAM_NAME}"

  # mediamtx：如果已经在跑（或端口被占用），就复用现有服务，不再重复启动。
  START_MEDIAMTX="${START_MEDIAMTX:-1}"
  if command -v ss >/dev/null 2>&1; then
    if ss -ltn 2>/dev/null | grep -q ":8554 "; then
      START_MEDIAMTX=0
      echo "[relay] 检测到 8554 已在监听，复用现有 mediamtx"
    fi
  fi

  if [ "$START_MEDIAMTX" = "1" ]; then
    echo "[relay] 启动 mediamtx ..."
    if [ -f "$MEDIA_MTX_CONF" ]; then
      "$MEDIA_MTX_BIN" "$MEDIA_MTX_CONF" >/tmp/mediamtx.log 2>&1 &
    else
      "$MEDIA_MTX_BIN" >/tmp/mediamtx.log 2>&1 &
    fi
    MEDIAMTX_PID=$!
    sleep 0.2
    if ! kill -0 "$MEDIAMTX_PID" >/dev/null 2>&1; then
      echo "[relay] mediamtx 启动失败（可能端口被占用）。你可以："
      echo "  1) 关闭已存在的 mediamtx 后重试；或"
      echo "  2) 复用现有 mediamtx：START_MEDIAMTX=0 USE_RELAY=1 ./run_rtsp_track.sh"
      echo "最近日志："
      tail -n 50 /tmp/mediamtx.log 2>/dev/null || true
      exit 3
    fi
  fi

  echo "[relay] 启动 ffmpeg relay (tcp + discardcorrupt+igndts+genpts) ..."
  ffmpeg -loglevel warning -rtsp_transport tcp \
    -fflags +discardcorrupt+igndts+genpts -err_detect ignore_err \
    -i "$RELAY_INPUT_RTSP" \
    -an -c:v h264_rkmpp -g 30 -bf 0 -b:v 4M -maxrate 4M -bufsize 1M \
    -f rtsp -rtsp_transport tcp "$RELAY_URL" \
    >/tmp/relay_ffmpeg.log 2>&1 &
  RELAY_PID=$!

  # 等待 relay 真正发布成功（mediamtx 在 publisher 未上线时 DESCRIBE 会 404，这是正常现象）
  for i in $(seq 1 50); do
    if ! kill -0 "$RELAY_PID" >/dev/null 2>&1; then
      echo "[relay] ffmpeg relay 已退出。最近日志："
      tail -n 80 /tmp/relay_ffmpeg.log 2>/dev/null || true
      exit 4
    fi

    if command -v ffprobe >/dev/null 2>&1; then
      if ffprobe -rtsp_transport tcp -v error -select_streams v:0 -show_entries stream=width -of csv=p=0 "$RELAY_URL" >/dev/null 2>&1; then
        break
      fi
    fi
    sleep 0.1
  done

  # 主程序读取“整形后的稳定流”
  # 进一步对齐你 Go 的打开方式：把低延迟参数挂在URL query上（OpenCV/FFmpeg会解析，mediamtx忽略）
  RELAY_READ_QUERY="${RELAY_READ_QUERY:-rtsp_transport=tcp&fflags=nobuffer&flags=low_delay&buffer_size=102400&timeout=10000000&max_delay=100000}"
  INPUT_RTSP="${RELAY_URL}?${RELAY_READ_QUERY}"
  echo "[relay] 主程序输入改为: $INPUT_RTSP"
  echo "[relay] 日志: /tmp/mediamtx.log  /tmp/relay_ffmpeg.log"
fi

# 运行程序
if [ -f ./build/yolov8_rtsp_track ]; then
    ./build/yolov8_rtsp_track "$MODEL_PATH" "$INPUT_RTSP" "$OUTPUT_RTSP" "$RECORD" "$DETECT_INTERVAL"
else
    echo "可执行文件不存在，请先编译: ./build_rtsp_track.sh"
fi
