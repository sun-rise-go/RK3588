这是一个可以在RK3588上运行的yolov8-bytetrack-demo项目，项目自带有量化后的官方模型可以进行测试使用。

说明：
在使用bytetrack之前需要先安装eigen3，具体操作如下：
创建任意目录并进入
git clone https://gitee.com/tangerine_yun/eigen-git-mirror.git
cd eigen-git-mirror
mkdir build
cd build
cmake ..
sudo make install